let form = document.getElementById('addForm');
let itemList = document.getElementById('items');
let filter = document.getElementById('filter');

// Form submit
form.addEventListener('submit', addItem);
// Delete
itemList.addEventListener('click', removeItem);
// Filter
filter.addEventListener('keyup', filterItems);
// CROSS
itemList.addEventListener('click', crossItem);

// Add item
function addItem(e){
  e.preventDefault();

  // Get input
  let newItem = document.getElementById('item').value;

  // Create new li element
  let li = document.createElement('li');
  // Add class
  li.className = 'list-group-item';
  // Add text node with input value
  li.appendChild(document.createTextNode(newItem));

  // Checkbox
  let checkBox = document.createElement("INPUT");
  checkBox.setAttribute("type", "checkbox");
  checkBox.className = 'checkBox';
  checkBox.style.margin = '10px';
  // Append to li
  li.appendChild(checkBox);

  // Create del button
  let deleteBtn = document.createElement('button');

  // Add classes to del button
  deleteBtn.className = 'btn btn-danger btn-sm float-right delete';

  // Append text node
  deleteBtn.appendChild(document.createTextNode('X'));

  // Append button to li
  li.appendChild(deleteBtn);

  // Append li to list
  itemList.appendChild(li);

}

// Remove item
function removeItem(event){
  if(event.target.classList.contains('delete')){
    if(confirm('Are You Sure?')){
      let li = event.target.parentElement;
      itemList.removeChild(li);
    }
  }
}

//STRIKE THROUGH
let clickCounter = 0;

function crossItem(e) {
  let li = e.target.parentElement;
  if (e.target.classList.contains('checkBox')) {
    if (clickCounter === 2) {
      if (confirm('Task not done?')) {
        li.style.textDecoration = 'none';
      }
    } else if (clickCounter === 3) {
      li.style.display = 'none';
      alert('Task is done! Stop checking the box or create a new task');
    } else {
      if (e.target.checked) {
        li.style.textDecoration = 'line-through';
      } else {
        li.style.textDecoration = 'none';
      }
      clickCounter = 0;
    }
    clickCounter++;
  }
}

// Filter Items
function filterItems(e){
  // Convert to lowercase
  let text = e.target.value.toLowerCase();
  let items = itemList.getElementsByTagName('li');
  // Convert to array
  Array.from(items).forEach(function(item){
    let itemName = item.firstChild.textContent;
    if(itemName.toLowerCase().indexOf(text) != -1){
      item.style.display = 'block';
    } else {
      item.style.display = 'none';
    }
  });
}